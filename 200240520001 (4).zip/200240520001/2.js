function validate() {
    // taking input
    let username = document.querySelector("#txt").value;
    console.log(username);


    let password = document.querySelector("#pass").value;
    console.log(password);

    let email = document.querySelector("#email").value;
    console.log(email);

    // validations
    if (username == "") {
        alert("username cannot be empty");
    }
    if (password == "") {
        alert("password cannot be empty");
    }

    if (email == "") {
        alert("email cannot be empty");
    }

    // clear fields
    document.querySelector("#txt").value = "";
    document.querySelector("#pass").value = "";
    document.querySelector("#email").value = "";

    // Display content
    document.querySelector("#display").innerHTML = "Username: " + username + "  /  Password: " + password + "  /  Email: " + email;


}